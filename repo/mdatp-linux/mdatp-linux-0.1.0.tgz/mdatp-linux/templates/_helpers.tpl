{{/*
Chart name.
*/}}
{{- define "mdatp.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Fully qualified app name.
*/}}
{{- define "mdatp.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "mdatp.labels" -}}
app.kubernetes.io/name: {{ include "mdatp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "mdatp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mdatp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Namespace.
*/}}
{{- define "mdatp.namespace" -}}
{{- default .Release.Namespace .Values.namespaceOverride }}
{{- end }}

{{/*
Container image.
*/}}
{{- define "mdatp.image" -}}
{{- printf "%s/%s:%s" .Values.image.registry .Values.image.repository .Values.image.tag }}
{{- end }}

{{/*
Detect OpenShift — checks security.openshift.io API presence (version-agnostic).
Returns "true" if OpenShift is detected or openshift.enabled is set.
*/}}
{{- define "mdatp.isOpenShift" -}}
{{- if .Values.openshift.enabled -}}
true
{{- else -}}
{{- range .Capabilities.APIVersions }}{{ if hasPrefix "security.openshift.io/" . }}true{{ end }}{{ end -}}
{{- end -}}
{{- end }}

{{/*
Host CA certificates path — resolves "auto" based on cluster type.
OpenShift → RHEL path. Otherwise → Debian/Ubuntu path.
Override with an explicit path for other distros.
*/}}
{{- define "mdatp.caCertsPath" -}}
{{- if eq .Values.hostCaCertsPath "auto" -}}
{{- if include "mdatp.isOpenShift" . -}}
/etc/pki/tls/certs/ca-bundle.crt
{{- else -}}
/etc/ssl/certs/ca-certificates.crt
{{- end -}}
{{- else -}}
{{ .Values.hostCaCertsPath }}
{{- end -}}
{{- end }}
